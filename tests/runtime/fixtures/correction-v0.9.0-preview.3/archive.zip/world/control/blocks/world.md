# World Rules

Write durable outcomes back to their natural owner.
